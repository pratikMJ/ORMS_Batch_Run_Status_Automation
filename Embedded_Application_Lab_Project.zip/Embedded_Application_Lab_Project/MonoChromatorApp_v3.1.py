from tkinter import *
window=Tk()
window.title("     ECSLAB | ATDC | IIT KHARAGPUR    ")
import matplotlib.pyplot as plt
import time
import paho.mqtt.client as paho
import csv

#define callback
def on_message(client, userdata, message):
    time.sleep(2)
    print("subscribing ")
    message_rec = str(message.payload.decode("utf-8"))
    print("received message =", message_rec)
    if len(message_rec)!=15:

        if int(message_rec)>=1 and int(message_rec)<=20:
            outp=int(message_rec) *5+108
            duckbox.append(float(outp))
        elif int(message_rec)>=21 and int(message_rec)<=40:
            outp = int(message_rec) * 35 -549
            duckbox.append(float(outp))
        elif int(message_rec) >= 41 and int(message_rec) <= 60:
            outp = int(message_rec) * 59 - 1508
            duckbox.append(float(outp))
        elif int(message_rec) >= 61 and int(message_rec) <= 80:
            outp = int(message_rec) * 23 + 712
            duckbox.append(float(outp))
        elif int(message_rec) >= 81 and int(message_rec) <= 100:
            outp = int(message_rec) * 4 + 2201
            duckbox.append(float(outp))
        elif int(message_rec) >= 101 and int(message_rec) <= 120:
            outp = int(message_rec) * 2 + 2323
            duckbox.append(float(outp))
        elif int(message_rec) >= 121 and int(message_rec) <= 140:
            outp = int(message_rec) * (-6) + 3203
            duckbox.append(float(outp))
        elif int(message_rec) >= 141 and int(message_rec) <= 160:
            outp = int(message_rec) * (-38) + 7772
            duckbox.append(float(outp))
        elif int(message_rec) >= 161 and int(message_rec) <= 180:
            outp = int(message_rec) * (-67) + 12305
            duckbox.append(float(outp))
        elif int(message_rec) >= 181 and int(message_rec) <= 200:
            outp = int(message_rec) * (-10) + 2061
            duckbox.append(float(outp))
        else:
            print("hello")


broker="192.168.43.241"
client= paho.Client("Photonics-App")
client.on_message=on_message
print("connecting to broker ",broker)
client.connect(broker)
duckbox=[]
x_axis_values=[]

def publish_message(payload):
    client.loop_start()
    time.sleep(2)
    print("publishing ")
    client.publish("ECSLAB|ATDC|IITKGP", payload)
    client.loop_stop()

def move_motor(dest):
    initial=inputs[0]
    final=dest
    temp=float(initial)-float(final)
    if temp!=0:
        if(temp<0):
            print("run forward,anti-clockwise movement ")
            direction=1
        else:
            print("run backward,clockwise movement")
            direction=0
        steps = int(abs(float(initial) - float(final))*10)
        temp2_str=str(steps)
        apnd = ""
        if len(temp2_str)!=5:
            length=len(temp2_str)
            diff=5-length
            for i in range (diff):
                apnd=apnd+"0"
            apnd=apnd+temp2_str
        else:
            apnd=apnd+temp2_str
        payload="0"+str(direction)+str(apnd)+"00000"+"000"
        publish_message(payload)
        inputs[0] = final
    else:
        print("Initial reading and set value both are same")

def move_motor_automation(dest):
    initial=inputs[0]
    final=dest
    temp=float(initial)-float(final)
    if temp!=0:
        if(temp<0):
            print("run forward,anti-clockwise movement ")
            direction=1
            final=final + int(inputs[2])
        else:
            print("run backward,clockwise movement")
            direction=0
            final = final - int(inputs[3])
        steps = int(abs(float(initial) - float(final))*10)
        temp2_str=str(steps)
        apnd = ""
        if len(temp2_str)!=5:
            length=len(temp2_str)
            diff=5-length
            for i in range (diff):
                apnd=apnd+"0"
            apnd=apnd+temp2_str
        else:
            apnd=apnd+temp2_str
        payload="0"+str(direction)+str(apnd)+"00000"+"000"
        publish_message(payload)
        inputs[0] = final
    else:
        print("Initial reading and set value both are same")

def start_automation():

    start=inputs[5]
    end=inputs[6]
    step=inputs[7]
    delay=inputs[8]
    diff=float(start)-float(end)
    #anticlockwise
    if diff<0:
        direction=1
    else:
        direction=0
    count_str=str(int(abs(diff)/float(step)))
    apnd=""
    if len(count_str)!=5:
        d=5-len(count_str)
        for i in range(d):
            apnd=apnd+"0"
        apnd=apnd+count_str
    else:
        apnd=apnd+count_str
    inner_count_str=str(int(float(step)*10))
    apnd1=""
    if len(inner_count_str)!=5:
        d=5-len(inner_count_str)
        for i in range(d):
            apnd1=apnd1+"0"
        apnd1=apnd1+inner_count_str
    else:
        apnd1=apnd1+inner_count_str
    apnd2=""
    if len(delay)!=3:
        d=3-len(delay)
        for i in range(d):
            apnd2=apnd2+"0"
        apnd2=apnd2+delay
    payload="1"+str(direction)+apnd+apnd1+apnd2
    publish_message(payload)
    client.loop_start()
    client.subscribe("ECSLAB|ATDC|IITKGP")  # subscribe


inputs=["0","0","0","0","0","0","0","0","0"]

def click_1():
    val_1= textBox1.get()
    inputs[0]=val_1
    textBox1.configure(state='disable')
    button1.configure(state='disable')
    textBox2.configure(state='normal')
    button2.configure(state='normal')

def click_2():
    val_2=textBox2.get()
    inputs[1]=val_2
    diff=float(inputs[1])-float(inputs[0])
    move_motor(inputs[1])
    if diff>0:
        textBox3.configure(state='disable')
        textBox4.configure(state='normal')
        button4.configure(state='normal')
    else:
        textBox3.configure(state='normal')
        button3.configure(state='normal')
        textBox4.configure(state='disable')

    textBox5.configure(state='normal')
    button5.configure(state='normal')


def click_3():
    val_3 = textBox3.get()
    inputs[2]=val_3
    print(val_3)
    textBox3.configure(state='disable')
    button3.configure(state='disable')


def click_4():
    val_4 = textBox4.get()
    inputs[3]=val_4
    print(val_4)
    textBox4.configure(state='disable')
    button4.configure(state='disable')

def click_5():
    val_5 = textBox5.get()
    inputs[4]=val_5
    print(val_5)
    textBox2.configure(state='disable')
    button2.configure(state='disable')
    textBox3.configure(state='disable')
    button3.configure(state='disable')
    textBox4.configure(state='disable')
    button4.configure(state='disable')
    textBox5.configure(state='disable')
    button5.configure(state='disable')
    textBox6.configure(state='normal')
    button6.configure(state='normal')

def click_6():
    val_6 = textBox6.get()
    print(val_6)
    temp=int(val_6)
    print(temp)
    bias=inputs[4]
    val_bias=int(inputs[4][1:])
    print("bias value: ",val_bias)
    if bias[0]=='+':
        temp=temp-val_bias
        temp = temp / 2
        inputs[5]=temp
    elif bias[0]=='-':
        temp=temp+val_bias
        temp = temp / 2
        inputs[5] = temp
    else:
        print("please put '+' or '-' before bias value")


    textBox6.configure(state='disable')
    button6.configure(state='disable')
    move_motor(inputs[5])
    textBox7.configure(state='normal')
    button7.configure(state='normal')

def click_7():
    val_7 = textBox7.get()
    print(val_7)
    temp = int(val_7)
    bias = inputs[4]
    val_bias = int(inputs[4][1:])
    print("bias:",val_bias)
    if bias[0] == '+':
        temp = temp - val_bias
        temp = temp / 2
        inputs[6] = temp
    elif bias[0] == '-':
        temp = temp + val_bias
        temp = temp / 2
        inputs[6] = temp
    else:
        print("please put '+' or '-' before bias value")

    print(val_7)
    textBox7.configure(state='disable')
    button7.configure(state='disable')
    textBox8.configure(state='normal')
    button8.configure(state='normal')

def click_8():
    val_8 = textBox8.get()
    inputs[7]=val_8
    val1=float(inputs[5])
    val2=float(inputs[6])
    counter=int((val2-val1)/float(inputs[7]))
    for i in range(counter):
        x_axis_values.append(val1+i*float(inputs[7]))
    textBox8.configure(state='disable')
    button8.configure(state='disable')
    textBox9.configure(state='normal')
    button9.configure(state='normal')

def click_9():
    val_9 = textBox9.get()
    inputs[8]=val_9
    print(val_9)
    textBox9.configure(state='disable')
    button9.configure(state='disable')

    start_automation()
    inputs[0]=inputs[6]
    button_gen.configure(state='normal')

def click_gen():
    co_x = x_axis_values
    co_y = duckbox
    plt.plot(co_x, co_y)
    plt.show()
    row=[['Wavelength','Laser Output']]
    for i in range(len(x_axis_values)):
        temp=[str(x_axis_values[i]),str(duckbox[i])]
        row.append(temp)
    with open('sample.csv', 'w')as writefile:
        writer = csv.writer(writefile)
        writer.writerows(row)
    writefile.close()


def click_reset():
    window.destroy()
    exit()


####### window creation and heading #######
#######  EXECUTION BEGINS  #########

header_label=Label(window, text="        Welcome to Photonics Lab", font=("ARIAL BOLD", 43),anchor='center',fg='Green')
header_label.grid(column=0, row=0)
window.geometry('1200x900')

design_label1=Label(window, text=" ..................................................", font=("ARIAL BOLD", 20),anchor='center')
design_label1.grid(column=0, row=10)
design_label2=Label(window, text=" Configuration", font=("ARIAL BOLD", 15), fg='Blue',anchor='center')
design_label2.grid(column=0, row=11)
design_label3=Label(window, text=" ..................................................", font=("ARIAL BOLD", 20),anchor='center')
design_label3.grid(column=0, row=12)

label1=Label(window, text="INITIAL Reading (meter reading)", font=("ARIAL", 20))
label1.grid(column=0, row=40)
textBox1=Entry(window, width=10)
textBox1.grid(column=1, row=40)
button1=Button(window, text="GO", command=click_1)
button1.grid(column=2, row=40)

label2=Label(window, text="Set Value (meter reading)", font=("ARIAL", 20))
label2.grid(column=0, row=50)
textBox2=Entry(window, width=10)
textBox2.configure(state='disable')
textBox2.grid(column=1, row=50)
button2=Button(window, text="ENTER", command=click_2)
button2.configure(state='disable')
button2.grid(column=2, row=50)

label3=Label(window, text="Clockwise Offset (meter reading)", font=("ARIAL", 20))
label3.grid(column=0, row=60)
textBox3=Entry(window, width=10)
textBox3.configure(state='disable')
textBox3.grid(column=1, row=60)
button3=Button(window, text="GO", command=click_3)
button3.configure(state='disable')
button3.grid(column=2, row=60)

label4=Label(window, text="Anti-clockwise Offset (meter reading)", font=("ARIAL", 20))
label4.grid(column=0, row=70)
textBox4=Entry(window, width=10)
textBox4.configure(state='disable')
textBox4.grid(column=1, row=70)
button4=Button(window, text="GO", command=click_4)
button4.configure(state='disable')
button4.grid(column=2, row=70)

label5=Label(window, text="Calibration Error (nm)", font=("ARIAL", 20))
label5.grid(column=0, row=90)
textBox5=Entry(window, width=10)
textBox5.configure(state='disable')
textBox5.grid(column=1, row=90)
button5=Button(window, text="GO", command=click_5)
button5.configure(state='disable')
button5.grid(column=2, row=90)

design_label4=Label(window, text=" ..................................................", font=("ARIAL BOLD", 20),anchor='center')
design_label4.grid(column=0, row=91)
design_label5=Label(window, text=" Automation", font=("ARIAL BOLD", 15), fg='Blue',anchor='center')
design_label5.grid(column=0, row=93)
design_label6=Label(window, text=" ..................................................", font=("ARIAL BOLD", 20),anchor='center')
design_label6.grid(column=0, row=95)

label6=Label(window, text="START Wavelength (nm)", font=("ARIAL", 20))
label6.grid(column=0, row=100)
textBox6=Entry(window, width=10)
textBox6.configure(state='disable')
textBox6.grid(column=1, row=100)
button6=Button(window, text="ENTER", command=click_6)
button6.configure(state='disable')
button6.grid(column=2, row=100)

label7=Label(window, text="END Wavelength (nm)", font=("ARIAL", 20))
label7.grid(column=0, row=110)
textBox7=Entry(window, width=10)
textBox7.configure(state='disable')
textBox7.grid(column=1, row=110)
button7=Button(window, text="GO", command=click_7)
button7.configure(state='disable')
button7.grid(column=2, row=110)

label8=Label(window, text="Step Size (>=0.1)", font=("ARIAL", 20))
label8.grid(column=0, row=120)
textBox8=Entry(window, width=10)
textBox8.configure(state='disable')
textBox8.grid(column=1, row=120)
button8=Button(window, text="GO", command=click_8)
button8.configure(state='disable')
button8.grid(column=2, row=120)

label9=Label(window, text="Wait Time(1-999 in sec)", font=("ARIAL", 20))
label9.grid(column=0, row=130)
textBox9=Entry(window, width=10)
textBox9.configure(state='disable')
textBox9.grid(column=1, row=130)
button9=Button(window, text="ENTER", command=click_9)
button9.configure(state='disable')
button9.grid(column=2, row=130)

button_gen=Button(window,text="GENERATE",command=click_gen)
button_gen.configure(state='disable')
button_gen.grid(column=2,row=180)

button_res=Button(window,text="RESET",command=click_reset)
button_res.grid(column=2,row=220)

window.mainloop()
client.disconnect()
client.loop_stop()

